<!DOCTYPE html>
<html lang="en">
<?php 
header('Cross-Origin-Opener-Policy: ');

?>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>gizidukasi</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="vendor/twbs/bootstrap/dist/css/bootstrap.min.css">
    <style>
        body {
            background-color: #f0f0f0;
            margin: 0;
            padding: 0;
            width: 100%;
            height: 100%;
        }

        #login-container {
            vertical-align: middle;
            text-align: center;
            padding: 20px;
            align-items: center;
            border-radius: 10px;
            background-image: url("assets/img/login_header.png");
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            background: hsla(0, 0%, 100%, 0.097);
            position: relative;
            z-index: 2;
        }

        .google-login-button {
            background-color: #5a8ee1;
            color: #fff;
            border: none;
            width: 100%;
            padding: 15px 15px;
            font-size: 16pt;
            border-radius: 5px;
        }

        #wave-container {
            position: relative;
            top: 0;
            height: 100%;
            width: 100%;
            overflow: hidden;

        }

        #wave {
            width: calc(100% + 1.3px);
            height: 100%;
            top: 0;
            transform: rotate(180deg);
        }
    </style>
</head>

<body>

    <div id="wave-container" style="">
        <svg xmlns:xlink="http://www.w3.org/1999/xlink" id="wave" viewBox="0 0 1440 500" version="1.1"
            xmlns="http://www.w3.org/2000/svg">
            <defs>
                <linearGradient id="sw-gradient-0" x1="0" x2="0" y1="1" y2="0">
                    <stop stop-color="rgba(255, 159, 252, 0.615686274509804)" offset="0%" />
                    <stop stop-color="rgba(251.613, 159, 255, 0.94)" offset="100%" />
                </linearGradient>
            </defs>
            <path fill="url(#sw-gradient-0)"
                d="M0,196L26.7,187.8C53.3,180,107,163,160,187.8C213.3,212,267,278,320,302.2C373.3,327,427,310,480,253.2C533.3,196,587,98,640,73.5C693.3,49,747,98,800,155.2C853.3,212,907,278,960,285.8C1013.3,294,1067,245,1120,228.7C1173.3,212,1227,229,1280,261.3C1333.3,294,1387,343,1440,375.7C1493.3,408,1547,425,1600,375.7C1653.3,327,1707,212,1760,204.2C1813.3,196,1867,294,1920,343C1973.3,392,2027,392,2080,343C2133.3,294,2187,196,2240,187.8C2293.3,180,2347,261,2400,318.5C2453.3,376,2507,408,2560,408.3C2613.3,408,2667,376,2720,318.5C2773.3,261,2827,180,2880,122.5C2933.3,65,2987,33,3040,24.5C3093.3,16,3147,33,3200,81.7C3253.3,131,3307,212,3360,245C3413.3,278,3467,261,3520,253.2C3573.3,245,3627,245,3680,277.7C3733.3,310,3787,376,3813,408.3L3840,441L3840,490L3813.3,490C3786.7,490,3733,490,3680,490C3626.7,490,3573,490,3520,490C3466.7,490,3413,490,3360,490C3306.7,490,3253,490,3200,490C3146.7,490,3093,490,3040,490C2986.7,490,2933,490,2880,490C2826.7,490,2773,490,2720,490C2666.7,490,2613,490,2560,490C2506.7,490,2453,490,2400,490C2346.7,490,2293,490,2240,490C2186.7,490,2133,490,2080,490C2026.7,490,1973,490,1920,490C1866.7,490,1813,490,1760,490C1706.7,490,1653,490,1600,490C1546.7,490,1493,490,1440,490C1386.7,490,1333,490,1280,490C1226.7,490,1173,490,1120,490C1066.7,490,1013,490,960,490C906.7,490,853,490,800,490C746.7,490,693,490,640,490C586.7,490,533,490,480,490C426.7,490,373,490,320,490C266.7,490,213,490,160,490C106.7,490,53,490,27,490L0,490Z" />
        </svg>
    </div>

    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-12 col-sm-10">
                <div id="login-container">
                    <h1>Gizidukasi</h1>

                    <img width='50%' src="assets/img/header.png" />
                    <div class="g-signin2" data-onsuccess="onSignIn"></div>


                    </button>
                </div>
            </div>
        </div>
    </div>
    <script src="https://accounts.google.com/gsi/client" async defer></script>
    <div>
    </div>
    <!-- Bootstrap JS and Popper.js (required for Bootstrap) -->
    <script src="vendor/components/jquery/jquery.min.js"></script>
    <script src="vendor/twbs/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>
<script src="https://apis.google.com/js/platform.js" async defer></script>
<meta name="google-signin-client_id" content="115551103032-vv18pau955lo1jeov8bvq1gq2teth5r4.apps.googleusercontent.com">
<script>

    function onSignIn(googleUser) {
        var profile = googleUser.getBasicProfile();
        console.log('ID: ' + profile.getId()); // Do not send to your backend! Use an ID token instead.
        console.log('Name: ' + profile.getName());
        console.log('Image URL: ' + profile.getImageUrl());
        console.log('Email: ' + profile.getEmail()); // This is null if the 'email' scope is not present.
    }
</script>